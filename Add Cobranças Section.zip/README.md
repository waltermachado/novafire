
  # Add Cobranças Section

  This is a code bundle for Add Cobranças Section. The original project is available at https://www.figma.com/design/N1syI7X5A2UYMuBhpqH8VY/Add-Cobran%C3%A7as-Section.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  